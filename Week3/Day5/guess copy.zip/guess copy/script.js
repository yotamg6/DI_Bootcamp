//work plan

//5. why the "time is up" alert is alerted when the clock shows 00:01? check the debugger
//6. limit num of guesses?
//7. add hints?
//8. UI
// a.set the two input fields apart
// b.turn the alerts into something nicer. it'll probably mean to change the text content of the div that will present the notifications
// c.include instruction into how the game works?
// c. the screen color could change when the guess is right (e.g js)
// add celebs
// before submitting: remove all consolelogs, reset the time to 120

//select elements
const btnAsk = document.querySelector(".btnAsk");
const btnGuess = document.querySelector(".btnGuess");
const btnReset = document.querySelector(".btnReset");
const card = document.querySelector(".card");
const askInputField = document.querySelector(".askInputField");
const guessInputField = document.querySelector(".guessInputField");
const timerBox = document.querySelector(".timerBox");
const timerDisplayed = document.querySelector(".timer");
const form = document.forms[0];

let time = 30;
let ranNum;
let timer;
let clickCounter = 0;
let isWord;
const celebrities = {
  c1: {
    fullName: "cristiano ronaldo",
    keyWords: [
      "sport",
      "player",
      "football",
      "footballer",
      "male",
      "man",
      "portugal",
      "manchester",
      "portugese",
    ],
  },
  c2: {
    fullName: "angelina jolie",
    keyWords: [
      "actress",
      "pitt",
      "adopt",
      "mrs",
      "smith",
      "director",
      "humanitarian",
      "american",
      "usa",
    ],
  },
  c3: {
    fullName: "steve jobs",
    keyWords: [
      "man",
      "buiseness",
      "buisenessman",
      "media",
      "apple",
      "ipod",
      "mac",
      "computer",
      "deceased",
      "american",
      "usa",
      "inventor",
      "pioneer",
    ],
  },
};

///
btnAsk.addEventListener("click", getInput);
btnGuess.addEventListener("click", getInput);
btnReset.addEventListener("click", reset);

function getInput(e) {
  e.preventDefault();
  const question = askInputField.value.toLowerCase();
  console.log(question);
  const guess = guessInputField.value.toLowerCase();
  //   console.log(guess);
  if (question && clickCounter === 0) {
    startGame();
    handleQuestions(question);
    // console.log("asked first", clickCounter);
    clickCounter++;
  } else if (question && clickCounter > 0 && time) {
    handleQuestions(question);
    // console.log("asked again", clickCounter);
  } else if (guess && clickCounter === 0) {
    startGame();
    handleGuesses(guess);
    // console.log("guessed first", clickCounter);
    clickCounter++;
  } else if (guess && clickCounter > 0 && time) {
    handleGuesses(guess);
    // console.log("guessed again", clickCounter);
  } else if (time == null)
    alert(
      "The game is over. please press the reset button to restart the game"
    );
  else alert("please ask a question or guess who the celebrity is");
}

function startGame() {
  ranNum = Math.trunc(Math.random() * 3) + 1;
  celebObj = "c" + ranNum;

  timer = setInterval(clock, 1000);
}

function clock() {
  const min = String(Math.trunc(time / 60)).padStart(2, 0);
  const sec = String(time % 60).padStart(2, 0);
  timerDisplayed.textContent = ` ${min}:${sec}`;

  if (time === 0) {
    clearInterval(timer);
    alert("time is up, the game is over");
    gameOver();
    // resetGame()
  } else {
    time--;
  }
}

function handleQuestions(question) {
  const quesElements = question.split(" ");
  const currentKWords = celebrities[celebObj]["keyWords"];
  console.log(currentKWords);
  for (let elem of quesElements) {
    isWord = currentKWords.some((kWord) => kWord == elem);
  }
  isWord ? alert("yes! you are getting closer") : alert("not quite, try again");
  form.reset();
}

function handleGuesses(guess) {
  if (guess.toLowerCase() == celebrities[celebObj]["fullName"]) {
    gameOver(guess);
    alert("Well done! you guessed right");
  } else {
    alert(`that's not who I am. Try again!`);
  }
  form.reset();
}

function gameOver() {
  const celebName = celebrities[celebObj]["fullName"].toUpperCase();
  //   card.classList.toggle("flippedCard", false);
  card.style.backgroundImage = `url("images/pic${ranNum}.jpeg")`;
  timerDisplayed.textContent = "00:00";
  //   timerBox.textContent = `The right guess was: ${celebName}`;
  clearInterval(timer);
  time = null;
}

function reset() {
  //   card.classList.toggle("flippedCard", true); //doesn't do anything
  card.style.backgroundImage = `linear-gradient(
    to bottom,
    rgba(61, 82, 199, 0.52),
    rgba(136, 134, 38, 0.73)
  ),
  url("images/guesspic.jpeg")`;
  time = 120;
  clickCounter = 0;
  timer = null;
  ranNum = null;
  //   timerBox.textContent = "Your time will end in 02:00";
  timerDisplayed.textContent = "02:00";
  console.log("timer value", timer);
  console.log("ranNum value", ranNum);
}
